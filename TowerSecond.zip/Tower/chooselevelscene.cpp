﻿#include "chooselevelscene.h"
#include "mypushbutton.h"
#include "playscene.h"

#include <QPainter>
#include <QDebug>
ChooseLevelScene::ChooseLevelScene(QWidget *parent)
    : QWidget(parent)
    , mBackground(":/resources/materials/levelscenebackground.png")
    , mBackButton(new MyPushButton(":/resources/materials/backbutton.png", ":/resources/materials/backbuttonselected.png", this))
    , mPlayScene(new PlayScene)
{
    hide();
    mLevelButtons.append(new MyPushButton(":/resources/materials/water.png", "", this));
    mLevelButtons.append(new MyPushButton(":/resources/materials/fire.png", "", this));

    connect(mBackButton, &QPushButton::clicked, this, &ChooseLevelScene::chooseSceneBack);

    foreach (MyPushButton *button, mLevelButtons)
        connect(button, &QPushButton::clicked, this, &ChooseLevelScene::levelButtonClicked);
}


ChooseLevelScene::~ChooseLevelScene()
{
    delete mPlayScene;
}

void ChooseLevelScene::levelButtonClicked()
{
    MyPushButton *button = qobject_cast<MyPushButton *>(sender());
    int index = mLevelButtons.indexOf(button);
    if (index != -1) {
        mPlayScene->deleteLater();
        mPlayScene = new PlayScene;
        mPlayScene->loadScene(index);
        mPlayScene->show();
    }
}

void ChooseLevelScene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawPixmap(rect(), mBackground);
}

void ChooseLevelScene::resizeEvent(QResizeEvent *event)
{
    QWidget::resizeEvent(event);
    mBackButton->move(width() - mBackButton->width(), height() - mBackButton->height());

    mLevelButtons.at(0)->move((width() - mLevelButtons.at(0)->width()) * 0.5, (height() - mLevelButtons.at(0)->height()) * 0.4);
    mLevelButtons.at(1)->move(mLevelButtons.at(0)->x() + mLevelButtons.at(0)->width() + 60, mLevelButtons.at(0)->y() + 40);
}


