﻿#include "bullet.h"
#include "gamehelper.h"

#include <QDebug>

Bullet::Bullet(QObject *parent)
{

}
