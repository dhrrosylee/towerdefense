﻿#include "playscene.h"
#include "tower.h"
#include "gamehelper.h"
#include "bullet.h"
#include "monster.h"

#include <QPainter>
#include <QDebug>
#include <QMouseEvent>
#include <QTimer>
#include <QTime>
#include <QMenu>
#include <QMessageBox>
#include <QRandomGenerator>

PlayScene::PlayScene(QWidget *parent)
    : QWidget(parent)
    , mLeftBg(new GameObject(this))
    , mRightBg(new GameObject(this))
    , mTowerSit(new GameObject(mLeftBg))
    , mDragTower(nullptr)
    , mFPSTimer(new QTimer(this))
    , mMonsterTimer(new QTimer(this))
    , mPlayerHealth(10)
    , mPlayerGold(100)
    , mCardGold(0)
    , mCurrentSceneIndex(0)
{
    setWindowIcon(QIcon(":/resources/materials/WindowIcon.png")); // 设置图标
    setWindowTitle("Tower");
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));


    hide();
    setFixedSize(1000, 1000);
    mBuffer = QPixmap(1000, 1000);
    mBuffer.fill(Qt::transparent);

    // 背景图片
    QPixmap left = QPixmap(":/resources/map/map3.jpg");
    QPixmap right = QPixmap(":/resources/materials/rightpicture.png");
    left = left.copy(0, 0, left.width(), left.height() - 200);  // -200是为了去掉底部的水印
    right = right.scaled(1000 - left.width(), left.height());
    mLeftBg->setBackground(left);
    mRightBg->setBackground(right);
    mRightBg->setPos(QPointF(left.width(), 0));

    // 炮塔底座
    QPixmap towerSit = QPixmap(":/resources/materials/towersit.png");
    mTowerSit->setBackground(towerSit);
    mTowerSit->setRect(QRectF(0, 0, towerSit.width(), towerSit.height()));
    mTowerSit->setPos(QPointF((left.width() - towerSit.width()) * 0.5, (left.height() - towerSit.height()) * 0.5));

    // 裁切矩形，即怪物、子弹、炮塔都裁切进炮塔底座的范围之内
    mClipRect = QRectF(mTowerSit->scenePos() + QPointF(0, 10), towerSit.size() - QSizeF(0, 20));

    // 计算炮塔底座位置（每个底座对应的矩形）9行5列
    const int TowerRows = 9;
    const int TowerColumns = 5;

    double x = mTowerSit->scenePos().x();
    double y = mTowerSit->scenePos().y();
    double w = towerSit.width() / TowerColumns;
    double h = towerSit.height() / TowerRows;
    mTowerSitRect.resize(TowerRows * TowerColumns);
    mTowers.resize(TowerRows * TowerColumns);

    for (int i = 0; i < TowerRows; ++i) {
        for (int j = 0; j < TowerColumns; ++j)
            mTowerSitRect[i * TowerColumns + j] = QRectF(x + j * w, y + i * h, w, h);
    }

    // 炮塔卡片
    x = 40;
    y = 28;
    for (int i = 0; i < 5; ++i) {
        Card *card = new Card(mRightBg);                   // 初级卡片
        Card *advancedCard = new Card(mRightBg);  // 高级卡片

        int type = i + 1;
        card->tower()->setType(type);
        card->setGold(type * 10);
        advancedCard->tower()->setType(type + 5);
        advancedCard->setGold(type * 10 + 5);
        mCards.append(card);
        mCards.append(advancedCard);

        if (i != 0) y += card->height() + 1;

        card->setPos(QPointF(x, y));
        advancedCard->setPos(QPointF(x + card->width() + 10, y));
    }

    // 定时器
    connect(mFPSTimer, &QTimer::timeout, this, &PlayScene::updateObjects);
    connect(mMonsterTimer, &QTimer::timeout, this, &PlayScene::generateMonster);

    setMouseTracking(true);
}

PlayScene::~PlayScene()
{
    clearAll();
}

//加载场景
void PlayScene::loadScene(int index)
{
    mCurrentSceneIndex = index;
    // 替换左边的背景
    QPixmap leftBg = mCurrentSceneIndex ? QPixmap(":/resources/map/map1.jpg") : QPixmap(":/resources/map/map3.jpg");
    mLeftBg->setBackground(leftBg.copy(0, 0, leftBg.width(), leftBg.height() - 200));

    startGame();
    drawToBuffer();
}

//每帧更新所有物体信息
void PlayScene::updateObjects()
{


    // 每帧所耗费的时间
    Time::deltaTime = Time::lastTime.msecsTo(QTime::currentTime()) / 1000.0;
    Time::lastTime = QTime::currentTime();

    // 处理碰撞
    collidingObjects();

    // 更新物体信息
    for (Tower *tower : mTowers) {
        if (tower)
            tower->update();
    }

    for (Monster *monster : mMonsters)
        monster->update();

    // 绘制到缓冲区
    drawToBuffer();
}

//怪物生成
void PlayScene::generateMonster()
{
    Monster *monster = new Monster;

    mBossTime -= mMonsterTimer->interval();  // mBossTime <= 0说明需要生成的是boss

    if (mCurrentSceneIndex == 0) {
        if (mBossTime <= 0) {
            mBossTime = 0;
            mMonsterTimer->stop();   // 停止生成怪物
            monster->setType(21);
        } else monster->setType(QRandomGenerator::global()->bounded(1, 11));        // 生成1-10的随机数
    } else {
        if (mBossTime <= 0) {
            mBossTime = 0;
            mMonsterTimer->stop();
            monster->setType(22);
        } else monster->setType(QRandomGenerator::global()->bounded(10, 21));     // 生成10-20的随机数

        monster->setSpeed(monster->speed() * 1.5);          // 增加怪物的速度，增加难度
    }

    int index = qrand() % 5;        // 在哪条路径生成
    QRectF rect = mTowerSitRect.at(index);
    monster->setPos(rect.x() + (rect.width() - monster->width()) * 0.5, rect.y() - monster->rect().height());

    mMonsters.append(monster);

    // 连接怪物死亡时的信号，将怪物删除掉，并且给玩家增加金币
    connect(monster, &Monster::death, [this](Monster *obj){
        if (obj->boss())
            mBossDied = true;
        mPlayerGold += obj->gold();
        mMonsters.removeOne(obj);
        obj->deleteLater();
    });
}

//清除所有信息
void PlayScene::clearAll()
{
    // 清除所有炮塔
    qDeleteAll(mTowers);
    for (int i = 0; i < mTowers.size(); ++i)
        mTowers[i] = nullptr;

    // 清除所有怪物
    qDeleteAll(mMonsters);
    mMonsters.clear();


}

void PlayScene::startGame()
{
    mBossTime = 1000 * 120;          // boss出现的时间, 2分钟
    mBossDied = false;
    // 重新计时
    Time::lastTime = QTime();
    mFPSTimer->start(1000 / Time::FPS);
    mMonsterTimer->start(2000);
}

void PlayScene::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        for (Card *card : mCards) {
            if (card->selectTest(event->pos()) && canBuyCard(card)) {   // 点击的卡片可以购买
                mDragTower = card->tower()->duplicate();                      // 复制一个炮塔
                GameBorder::centerRect(mDragTower);                             // 将其原点设置在中心
                mDragTower->setPos(event->pos());                                 // 将其位置设置为鼠标的位置
                mCardGold = card->gold();                                                // 保存当前卡片需要消耗的金币值
                break;
            }
        }
    }
}

void PlayScene::mouseMoveEvent(QMouseEvent *event)
{
    if (mDragTower) {
        mDragTower->setPos(event->pos());
        update();
        return;
    }

    // 鼠标形状变化
    bool cursorChanged = false;
    for (Card *card : mCards) {
        if (card->selectTest(event->pos())) {
            cursorChanged = true;
            setCursor(Qt::PointingHandCursor);
            break;
        }
    }

    if (!cursorChanged)
        unsetCursor();
}

void PlayScene::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton && mDragTower) {
        int index = selectTestSitrect(event->pos());
        if (index == -1 || mTowers[index])    // 点击的不是炮塔底座或者当前底座已经存在炮塔了
            return;

        mPlayerGold -= mCardGold;           // 减少玩家金币
        mCardGold = 0;
        mDragTower->enableBlood(true);  // 开启塔的血条显示
        mDragTower->setPos(mTowerSitRect.at(index).center());  // 设置塔位置
        mTowers[index] = mDragTower;
        mDragTower = nullptr;

        // 当塔死亡的时候销毁塔
        connect(mTowers[index], &Tower::death, [this, index](Tower *tower) {
            tower->deleteLater();
            mTowers[index] = nullptr;
        });

        update();
    }
}

void PlayScene::contextMenuEvent(QContextMenuEvent *event)
{
    if (mDragTower) {   // 取消购买卡片
        mCardGold = 0;
        mDragTower->deleteLater();
        mDragTower = nullptr;
        update();
        return;
    }
}

void PlayScene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawPixmap(rect(), mBuffer);
}

void PlayScene::draw(QPainter *painter, GameObject *object)
{
    if (!object) return;

    painter->save();
    painter->translate(object->scenePos());
    painter->rotate(object->rotation());
    object->draw(painter);
    painter->restore();
}

//绘制玩家信息
void PlayScene::drawPlayerInfo(QPainter *painter)
{
    QRectF textRect = QRectF(width() - mRightBg->width() + 50, 700, mRightBg->width() - 50, 300);

    QString text = QString("生命值：%1\n金   币：%2").arg(mPlayerHealth).arg(mPlayerGold);
    QFont font("Microsoft YaHei", 24);
    font.setBold(true);
    painter->setFont(font);
    painter->drawText(textRect, Qt::AlignTop | Qt::AlignLeft, text);
}

void PlayScene::drawToBuffer()
{
    mBuffer.fill(Qt::transparent);
    QPainter painter(&mBuffer);

    draw(&painter, mLeftBg);

    painter.save();
    painter.setClipRect(mClipRect); // 将绘制范围限制在底座范围之内


    // 绘制怪物
    for (Monster *monster : mMonsters)
        draw(&painter, monster);

    // 绘制塔
    for (Tower *tower : mTowers)
        draw(&painter, tower);

    painter.restore();

    // 绘制右边的背景
    draw(&painter, mRightBg);

    // 绘制玩家信息
    drawPlayerInfo(&painter);

    // 绘制鼠标拖动时的塔
    draw(&painter, mDragTower);

    update();
}

void PlayScene::collidingObjects()
{
//怪物与塔的碰撞
    for (int i = mMonsters.size() - 1; i >= 0; --i) {
        Monster *monster = mMonsters.at(i);

        // 怪物超出了可视范围，玩家掉血
        if (monster->scenePos().y() > mClipRect.bottom()) {
            mPlayerHealth -= monster->atk();
            if (mPlayerHealth < 0) mPlayerHealth = 0;
            monster->deleteLater();
            mMonsters.removeAt(i);
            continue;
        }

        QRectF rect = QRectF(monster->scenePos(), monster->rect().size()) & mClipRect;

        // 处理与塔的碰撞
        for (int j = mTowers.size() - 1; j >= 0; --j) {
            if (!mTowers[j]) continue;

            // 塔受伤
            if (rect.intersects(mTowerSitRect.at(j))) {
                mTowers[j]->takeDamage(monster->atk());

                // 普通怪的话直接死掉，boss可以继续往下走
                if (!monster->boss()) {
                    monster->deleteLater();
                    monster = nullptr;
                    mMonsters.removeAt(i);
                }
                break;      // 怪物只会与一个塔碰撞，所以这里直接跳出来
            }
        }

        if (!monster)
            continue;      // 怪物有可能被删除掉了，所以这里就不往下了

    }
}

void PlayScene::stopTimer()
{
    mFPSTimer->stop();
    mMonsterTimer->stop();
}

//返回点击的是哪个炮塔底座
int PlayScene::selectTestSitrect(const QPointF &pos)
{
    for (int i = mTowerSitRect.size() - 1; i >= 0; --i) {
        QRectF rect = mTowerSitRect.at(i);
        if (rect.contains(pos))
            return i;
    }
    return -1;
}

//根据type查找对应的卡片
Card *PlayScene::findCard(int type)
{
    for (Card *card : mCards) {
        if (card->tower()->type() == type)
            return card;
    }
    return nullptr;
}

//是否可以购买卡片
bool PlayScene::canBuyCard(Card *card)
{
    return (mPlayerGold >= card->gold());
}


