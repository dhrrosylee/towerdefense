﻿#include "tower.h"
#include "gamehelper.h"
#include "bullet.h"
#include "blood.h"

#include <QDebug>
#include <QPainter>

Tower::Tower(QObject *parent)
    : GameObject(parent)
    , mIsAdvance(false)
    , mType(0)
    , mBlood(nullptr)
{
    setType(1);
}

Tower::~Tower()
{
}

//设置炮塔的类型

void Tower::setType(int type)
{
    if (mType == type) return;
    QString path,bulletPath;

    if (type > 0 && type <= 5) {        // 基础炮塔
        mIsAdvance = false;
        mType = type;
        path = QString(":/resources/tower/tower%1primary.png").arg(type);
        bulletPath = QString(":/resources/bullet/Bullet%1Primary.png").arg(type);
    } else if (type > 5 && type <= 10) {   // 升级版炮塔
        mIsAdvance = true;
        mType = type;
        path = QString(":/resources/tower/tower%1advanced.png").arg(type - 5);
        bulletPath = QString(":/resources/bullet/Bullet%1Advanced.png").arg(type - 5);
    }

    // 背景图片
    if (!path.isEmpty())
        setBackground(QPixmap(path));

    // 血条
    if (mBlood) {
        mBlood->setRect(QRectF(0, 0, width() - 10, 5));
        mBlood->setPos(-mBlood->width() * 0.5, -height() * 0.5);
        mBlood->maxHealth = mBlood->currentHealth = 5;
    }

}

//开启/关闭血条显示，默认关闭的

void Tower::enableBlood(bool enable)
{
    delete mBlood;
    mBlood = enable ? new Blood(this) : nullptr;

    if (mBlood) {
        mBlood->setRect(QRectF(0, 0, width() - 10, 5));
        mBlood->setPos(-mBlood->width() * 0.5, -height() * 0.5);
        mBlood->maxHealth = mBlood->currentHealth = 5;
    }
}

//复制tower

void Tower::copyOther(const Tower &other)
{
    GameObject::copyOther(other);

    setType(other.type());

    if (mBlood) {
        mBlood->deleteLater();
        mBlood = nullptr;
    }

    if (other.mBlood)
        mBlood = other.mBlood->duplicate();
}

void Tower::takeDamage(int damage)
{
    if (!mBlood) return;

    mBlood->currentHealth -= damage;
    if (mBlood->currentHealth <= 0) {
        mBlood->currentHealth = 0;
        emit death(this);
    }
}

//复制一个炮塔

Tower *Tower::duplicate() const
{
    Tower *tower = new Tower;
    tower->copyOther(*this);
    return tower;
}


Card::Card(QObject *parent)
    : GameObject(parent)
    , mTower(new Tower(this))
    , mGold(0)
{
    setBackground(QPixmap(":/resources/materials/cardsitdeep.png"));
    mTower->setPos(QPointF((width() - mTower->width()) * 0.5, (height() - mTower->height()) * 0.5));
}

void Card::setGold(int gold)
{
    mGold = gold;
}

void Card::draw(QPainter *painter)
{
    GameObject::draw(painter);

    QFont font("Microsoft YaHei", 24);
    font.setBold(true);
    painter->setFont(font);
    painter->setPen(QColor(255, 215, 0));
    painter->drawText(rect(), Qt::AlignCenter, QString::number(mGold));
}
