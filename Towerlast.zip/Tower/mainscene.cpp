﻿#include "mainscene.h"
#include "mypushbutton.h"
#include "chooselevelscene.h"

#include <QPainter>
#include <QDebug>

MainScene::MainScene(QWidget *parent)
    : QMainWindow(parent)
    , mStartButton(new MyPushButton(":/resources/materials/startbutton.png", "", this))
    , mChooseLevelScene(new ChooseLevelScene)
{
    setWindowIcon(QIcon(":/resources/materials/WindowIcon.png")); // 设置图标
    setWindowTitle(tr("Tower Defense")); // 设置标题
    mBackground = QPixmap(":/resources/materials/mainscene.jpg");  // 背景

    setFixedSize(1920, 1000);
    mChooseLevelScene->setFixedSize(size());
    mChooseLevelScene->setWindowIcon(windowIcon());

    // 点击开始按钮，隐藏当前窗口，显示选择场景的窗口
    connect(mStartButton, &QPushButton::clicked, mChooseLevelScene, &QWidget::show);

    connect(mStartButton, &QPushButton::clicked, this, &QWidget::hide);

    // 选择场景窗口返回，重新显示当前窗口
    connect(mChooseLevelScene, &ChooseLevelScene::chooseSceneBack, mChooseLevelScene, &QWidget::hide);
    connect(mChooseLevelScene, &ChooseLevelScene::chooseSceneBack, this, &QWidget::show);
}

MainScene::~MainScene()
{
    delete mChooseLevelScene;
}

void MainScene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawPixmap(rect(), mBackground);
}

void MainScene::resizeEvent(QResizeEvent *event)
{
    QMainWindow::resizeEvent(event);
    mStartButton->move((width() - mStartButton->width()) * 0.5, (height() - mStartButton->height()));
}
