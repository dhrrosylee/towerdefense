﻿#ifndef PLAYSCENE_H
#define PLAYSCENE_H

#include <QWidget>
#include <QMediaPlayer>
//static const QString s_curDir = "C:/Users/DELL/Desktop/music";
class GameObject;
class QPainter;
class Card;
class Tower;
class Monster;
class QMenu;
class Bullet;
class PlayScene : public QWidget
{
    Q_OBJECT
public:
    enum GameState {
        PauseState,
        // 暂停
        LoadingState,
        // 过场动画
        FailedState,
        // 游戏失败
        GamingState,
        // 游戏中
        SuccessState,
        // 游戏胜利
    };

    explicit PlayScene(QWidget *parent = nullptr);
    ~PlayScene();

    void setGameState(GameState state);

public slots:
    void loadScene(int index);
    void updateObjects();
    void generateMonster();
    void clearAll();
    void triggeredAction(QAction *action);
    void startGame();

protected:
    virtual void mousePressEvent(QMouseEvent *event);
    virtual void mouseMoveEvent(QMouseEvent *event);
    virtual void mouseReleaseEvent(QMouseEvent *event);
    virtual void contextMenuEvent(QContextMenuEvent *event);
    virtual void paintEvent(QPaintEvent *);
    virtual void closeEvent(QCloseEvent *);
    virtual void draw(QPainter *painter, GameObject *object);

    void drawPlayerInfo(QPainter *painter);
    void drawToBuffer();
    void collidingObjects();
    void stopTimer();
    int selectTestSitrect(const QPointF &pos);
    Card *findCard(int type);
    bool canBuyCard(Card *card);
    bool checkSceneSuccess();
    bool checkGameOver();

protected:
    GameState mGameState;
    // 游戏状态
    GameObject *mLeftBg;
    // 左边的背景
    GameObject *mRightBg;
    // 右边的背景
    GameObject *mTowerSit;
    // 炮塔底座
    Tower *mDragTower;
    // 当前在拖拽的炮塔
    QList<Card *> mCards;
    // 炮塔卡片
    QVector<QRectF> mTowerSitRect;
    // 保存炮塔底座位置
    QVector<Tower *> mTowers;
    // 炮塔
    QVector<Monster *> mMonsters;
    // 怪物
    QTimer *mFPSTimer;
    // FPS计时器
    QTimer *mMonsterTimer;
    // 怪物生成计时器
    QTimer *mLoadingTimer;
    // 倒计时
    QMenu *mMenu;
    // 右键菜单
    QAction *mDeleteAction;
    // 拆除
    QAction *mUpgradeAction;
    // 升级
    QPixmap mBuffer;
    // 双缓冲绘图
    QRectF mClipRect;
    // 绘制范围
    int mPlayerHealth;
    // 玩家生命值
    int mPlayerGold;
    // 玩家金币值
    int mCardGold;
    // 卡片的金币值
    int mCurrentSceneIndex;
    // 当前场景
    int mBossTime;
    // 开始生成boss的时间
    int mLoading;
    // 倒计时
    bool mBossDied;
    // 判断boss是否死亡，游戏结束条件之一
    QVector<int> mRoadMonsters;
    // 每条路径上的怪物个数
    QMediaPlayer *m_backgroundMusic;
    //前两个场景的背景音乐
    QMediaPlayer *m_backgroundMusic1;
    //游戏场景的背景音乐
    QMediaPlayer *m_winMusic;
    //胜利场景背景音乐
    QMediaPlayer *m_loseMusic;
    //失败场景背景音乐
    QMediaPlayer *m_BossDeath;
    //boss死亡音效
    QMediaPlayer *m_NormalDeath;
    //普通敌人死亡音效
    QMediaPlayer *m_Bullet;
    //子弹打到敌人音效
    QMediaPlayer *m_TowerPlace;
    //塔被打死音效
    QMediaPlayer *m_health;
    //玩家生命值减少音效
};

#endif // PLAYSCENE_H
