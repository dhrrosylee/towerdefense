﻿#ifndef CHOOSELEVELSCENE_H
#define CHOOSELEVELSCENE_H

#include <QWidget>
#include <QRandomGenerator>
class MyPushButton;
class PlayScene;
class MainScene;
class ChooseLevelScene : public QWidget
{
    Q_OBJECT
public:
    explicit ChooseLevelScene(QWidget *parent = nullptr);
    ~ChooseLevelScene();

signals:
    void chooseSceneBack();

protected slots:
    void levelButtonClicked();

protected:
    virtual void paintEvent(QPaintEvent *);
    virtual void resizeEvent(QResizeEvent *event);
    virtual void closeEvent(QCloseEvent *);

protected:
    QPixmap mBackground;
    MyPushButton *mBackButton;
    QList<MyPushButton *> mLevelButtons;

    PlayScene *mPlayScene;
};

#endif // CHOOSELEVELSCENE_H
