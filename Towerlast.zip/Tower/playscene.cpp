﻿#include "playscene.h"
#include "tower.h"
#include "gamehelper.h"
#include "bullet.h"
#include "monster.h"
#include "mainscene.h"
#include <QPainter>
#include <QDebug>
#include <QMouseEvent>
#include <QTimer>
#include <QTime>
#include <QMenu>
#include <QMessageBox>
#include <QRandomGenerator>
static const QString s_curDir = "C:/Users/DELL/Desktop/music";
PlayScene::PlayScene(QWidget *parent)
    : QWidget(parent)
    , mLeftBg(new GameObject(this))
    , mRightBg(new GameObject(this))
    , mTowerSit(new GameObject(mLeftBg))
    , mDragTower(nullptr)
    , mFPSTimer(new QTimer(this))
    , mMonsterTimer(new QTimer(this))
    , mLoadingTimer(new QTimer(this))
    , mPlayerHealth(10)
    , mPlayerGold(100)
    , mCardGold(0)
    , mCurrentSceneIndex(0)
    , m_backgroundMusic(NULL)
    , m_backgroundMusic1(NULL)
    , m_winMusic(NULL)
    , m_loseMusic(NULL)
    , m_BossDeath(NULL)
    , m_NormalDeath(NULL)
    , m_Bullet(NULL)
    , m_TowerPlace(NULL)
    , m_health(NULL)
{
    setWindowIcon(QIcon(":/resources/materials/WindowIcon.png")); // 设置图标
    setWindowTitle("Tower");

    mRoadMonsters.resize(5);

    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    mMenu = new QMenu(this);
    mDeleteAction = new QAction("拆除", this);
    mUpgradeAction = new QAction("升级", this);
    connect(mMenu, &QMenu::triggered, this, &PlayScene::triggeredAction);

    hide();
    setFixedSize(1000, 1000);
    mBuffer = QPixmap(1000, 1000);
    mBuffer.fill(Qt::transparent);

    // 背景图片
    QPixmap left = QPixmap(":/resources/map/map3.jpg");
    QPixmap right = QPixmap(":/resources/materials/rightpicture.png");
    left = left.copy(0, 0, left.width(), left.height() - 200);  // -200是为了去掉底部的水印
    right = right.scaled(1000 - left.width(), left.height());
    mLeftBg->setBackground(left);
    mRightBg->setBackground(right);
    mRightBg->setPos(QPointF(left.width(), 0));

    // 炮塔底座
    QPixmap towerSit = QPixmap(":/resources/materials/towersit.png");
    mTowerSit->setBackground(towerSit);
    mTowerSit->setRect(QRectF(0, 0, towerSit.width(), towerSit.height()));
    mTowerSit->setPos(QPointF((left.width() - towerSit.width()) * 0.5, (left.height() - towerSit.height()) * 0.5));

    // 裁切矩形，即怪物、子弹、炮塔都裁切进炮塔底座的范围之内
    mClipRect = QRectF(mTowerSit->scenePos() + QPointF(0, 10), towerSit.size() - QSizeF(0, 20));

    // 计算炮塔底座位置（每个底座对应的矩形）
    const int TowerRows = 9;
    const int TowerColumns = 5;

    double x = mTowerSit->scenePos().x();
    double y = mTowerSit->scenePos().y();
    double w = towerSit.width() / TowerColumns;
    double h = towerSit.height() / TowerRows;
    mTowerSitRect.resize(TowerRows * TowerColumns);
    mTowers.resize(TowerRows * TowerColumns);

    for (int i = 0; i < TowerRows; ++i) {
        for (int j = 0; j < TowerColumns; ++j)
            mTowerSitRect[i * TowerColumns + j] = QRectF(x + j * w, y + i * h, w, h);
    }

    // 炮塔卡片
    x = 40;
    y = 28;
    for (int i = 0; i < 5; ++i) {
        Card *card = new Card(mRightBg);                   // 初级卡片
        Card *advancedCard = new Card(mRightBg);  // 高级卡片

        int type = i + 1;
        card->tower()->setType(type);
        card->setGold(type * 10);
        advancedCard->tower()->setType(type + 5);
        advancedCard->setGold(type * 10 + 5);
        mCards.append(card);
        mCards.append(advancedCard);

        if (i != 0) y += card->height() + 1;

        card->setPos(QPointF(x, y));
        advancedCard->setPos(QPointF(x + card->width() + 10, y));
    }

    // 定时器
    connect(mFPSTimer, &QTimer::timeout, this, &PlayScene::updateObjects);
    connect(mMonsterTimer, &QTimer::timeout, this, &PlayScene::generateMonster);
    connect(mLoadingTimer, &QTimer::timeout, this, [this]() {
        mLoading--;
        if (mLoading <= 0) {          // 倒计时完毕，开始游戏
            mLoadingTimer->stop();
            startGame();
        } else drawToBuffer();
    });
    m_backgroundMusic = new QMediaPlayer(this);
    m_backgroundMusic->setMedia(QUrl::fromLocalFile(s_curDir + "/bgm.mp3"));
    m_backgroundMusic->play();
    m_backgroundMusic1 = new QMediaPlayer(this);
    m_backgroundMusic1->setMedia(QUrl::fromLocalFile(s_curDir + "/bgm1.mp3"));
    m_winMusic = new QMediaPlayer(this);
    m_winMusic->setMedia(QUrl::fromLocalFile(s_curDir + "/success.mp3"));
    m_loseMusic = new QMediaPlayer(this);
    m_loseMusic->setMedia(QUrl::fromLocalFile(s_curDir + "/fail.mp3"));
    m_BossDeath = new QMediaPlayer(this);
    m_BossDeath->setMedia(QUrl::fromLocalFile(s_curDir + "/bossDie.mp3"));
    m_NormalDeath = new QMediaPlayer(this);
    m_NormalDeath->setMedia(QUrl::fromLocalFile(s_curDir + "/placetower.mp3"));
    m_Bullet = new QMediaPlayer(this);
    m_Bullet->setMedia(QUrl::fromLocalFile(s_curDir + "/Bullet.mp3"));
    m_TowerPlace = new QMediaPlayer(this);
    m_TowerPlace->setMedia(QUrl::fromLocalFile(s_curDir + "/NormalDie.mp3"));
    m_health = new QMediaPlayer(this);
    m_health->setMedia(QUrl::fromLocalFile(s_curDir + "/health.mp3"));
    setGameState(PauseState);
    setMouseTracking(true);
}

PlayScene::~PlayScene()
{
    clearAll();
}

void PlayScene::setGameState(PlayScene::GameState state)
{
    mGameState = state;

    switch (mGameState) {
    case PauseState:
        stopTimer();
        break;
    case LoadingState:
        m_backgroundMusic->stop();
        m_backgroundMusic1->play();
        break;
    case FailedState:
        m_backgroundMusic1->stop();
        m_loseMusic->play();
        stopTimer();
        QMessageBox::information(this, "提示", "很遗憾，游戏失败了，请再接再厉吧！");
        break;
    case GamingState:
        if (!mFPSTimer->isActive() || !mMonsterTimer->isActive()) {        // 如果计时器停止了，就重新开启它
            Time::lastTime = QTime();
            mFPSTimer->start();
            mMonsterTimer->start();
        }
        break;
    case SuccessState:
        m_backgroundMusic1->stop();
        m_winMusic->play();
        stopTimer();
        QMessageBox::information(this, "提示", "恭喜你！赢得游戏了！");
        m_backgroundMusic->stop();
        break;
    }
}

//加载场景
void PlayScene::loadScene(int index)
{
    mCurrentSceneIndex = index;
    // 替换左边的背景
    QString path = QString(":/resources/map/map%1.jpg").arg(index);
    QPixmap leftBg = QPixmap(path);
    mLeftBg->setBackground(leftBg.copy(0, 0, leftBg.width(), leftBg.height() - 200));

    stopTimer();
    clearAll();

    setGameState(LoadingState);
    mLoading = 5;
    mLoadingTimer->start(1000);
    drawToBuffer();
}

//更新所有物体信息
void PlayScene::updateObjects()
{
    if (Time::lastTime.isNull()) {
        Time::lastTime = QTime::currentTime();
        setGameState(GamingState);
        return;
    }

    // 首先判断游戏是否结束
    if (checkGameOver()) {
        setGameState(FailedState);
        return;
    }

    // 之后判断当前场景是否结束
    if (checkSceneSuccess()) {
        if (mCurrentSceneIndex == 0) loadScene(mCurrentSceneIndex + 1);   // 加载下一个场景
        else {
            setGameState(SuccessState);
            return;
        }
    }

    // 每帧所耗费的时间
    Time::deltaTime = Time::lastTime.msecsTo(QTime::currentTime()) / 1000.0;
    Time::lastTime = QTime::currentTime();

    // 处理碰撞
    collidingObjects();

    // 更新物体信息
    for (int i = 0; i < mTowers.size(); ++i) {
        if (!mTowers[i])
            continue;

        if (mTowers[i]->type() == 5 || mTowers[i]->type() == 10) {
            // 可以发射多个子弹的塔，只要任意路径上有怪物就可以发射子弹
            for (int road = 0; road < mRoadMonsters.size(); ++road) {
                if (mRoadMonsters[road]) {
                    mTowers[i]->update();
                    break;
                }
            }
        } else if (mRoadMonsters[i % 5])   // 对于其它的塔，需要当前路径上有怪物才可以发射子弹
            mTowers[i]->update();
    }

    for (Bullet *bullet : GameManager::TotalBullet)
        bullet->update();

    for (Monster *monster : mMonsters)
        monster->update();

    // 绘制到缓冲区
    drawToBuffer();
}

//怪物生成
void PlayScene::generateMonster()
{
    Monster *monster = new Monster;

    mBossTime -= mMonsterTimer->interval();  // mBossTime <= 0说明需要生成的是boss

    if (mCurrentSceneIndex) {
        if (mBossTime <= 0) {
            mBossTime = 0;
            mMonsterTimer->stop();   // 停止生成怪物
            monster->setType(22);
        } else monster->setType(QRandomGenerator::global()->bounded(1, 21));        // 生成1-10的随机数
    } /*else {
        if (mBossTime <= 0) {
            mBossTime = 0;
            mMonsterTimer->stop();
            monster->setType(22);
        } else monster->setType(QRandomGenerator::global()->bounded(10, 21));     // 生成10-20的随机数

        monster->setSpeed(monster->speed() * 2);          // 增加怪物的速度，增加难度
    }*/

    int index = qrand() % 5;         // 在哪条路径生成
    mRoadMonsters[index]++;   // 当前路径怪物数量增加

    QRectF rect = mTowerSitRect.at(index);
    monster->road = index;       // 设置怪物所在的路径，以便在怪物死亡时减少当前路径怪物数量
    monster->setPos(rect.x() + (rect.width() - monster->width()) * 0.5, rect.y() - monster->rect().height());
    mMonsters.append(monster);

    // 连接怪物死亡时的信号，将怪物删除掉，并且给玩家增加金币
    connect(monster, &Monster::death, [this](Monster *obj){
        if (obj->boss())
            mBossDied = true;
        mRoadMonsters[obj->road]--;       // 减少怪物数量
        mPlayerGold += obj->gold();
        if(obj->boss())m_BossDeath->play();
        else m_NormalDeath->play();
        mMonsters.removeOne(obj);
        obj->deleteLater();
    });
}

//清除所有信息
void PlayScene::clearAll()
{
    // 清除所有炮塔
    qDeleteAll(mTowers);
    for (int i = 0; i < mTowers.size(); ++i)
        mTowers[i] = nullptr;

    // 清除所有怪物
    qDeleteAll(mMonsters);
    mMonsters.clear();

    // 清除所有子弹
    qDeleteAll(GameManager::TotalBullet);
    GameManager::TotalBullet.clear();
}

//拆除和升级功能
void PlayScene::triggeredAction(QAction *action)
{
    int index = selectTestSitrect(mapFromGlobal(QCursor::pos()));
    if (index == -1 || !mTowers[index])
        return;

    if (action == mDeleteAction) {
        // 拆除返还一半的金币
        Card *card = findCard(mTowers[index]->type());
        mPlayerGold += card->gold() * 0.5;

        mTowers[index]->deleteLater();
        mTowers[index] = nullptr;
    } else if (action == mUpgradeAction) {
        // 升级需要扣除金币
        int type = mTowers[index]->type() + 5;
        Card *card = findCard(type);
        if (!card) {
            return;
        }

        mPlayerGold -= card->gold();
        mTowers[index]->setType(type);
    }
}

void PlayScene::startGame()
{
    mBossTime = 1000 * 120;          // boss出现的时间, 2分钟
    mBossDied = false;
    // 重新计时
    Time::lastTime = QTime();
    mFPSTimer->start(1000 / Time::FPS);
    mMonsterTimer->start(2000);

}

void PlayScene::mousePressEvent(QMouseEvent *event)
{
    if (mGameState != GamingState)
        return;

    if (event->button() == Qt::LeftButton) {
        for (Card *card : mCards) {
            if (card->tower()->isAdvanced())
                continue;
            if (card->selectTest(event->pos()) && canBuyCard(card)) {   // 点击的卡片可以购买
                mDragTower = card->tower()->duplicate();                      // 复制一个炮塔
                GameBorder::centerRect(mDragTower);                             // 将其原点设置在中心
                mDragTower->setPos(event->pos());                                 // 将其位置设置为鼠标的位置
                mCardGold = card->gold();                                                // 保存当前卡片需要消耗的金币值
                break;
            }
        }
    }
}

void PlayScene::mouseMoveEvent(QMouseEvent *event)
{
    if (mDragTower) {
        mDragTower->setPos(event->pos());
        update();
        return;
    }

    // 鼠标形状变化
    bool cursorChanged = false;
    for (Card *card : mCards) {
        if (card->selectTest(event->pos())) {
            cursorChanged = true;
            setCursor(Qt::PointingHandCursor);
            break;
        }
    }

    if (!cursorChanged)
        unsetCursor();
}

void PlayScene::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton && mDragTower) {
        int index = selectTestSitrect(event->pos());
        if (index == -1 || mTowers[index])    // 点击的不是炮塔底座或者当前底座已经存在炮塔了
            return;

        mPlayerGold -= mCardGold;           // 减少玩家金币
        mCardGold = 0;
        mDragTower->enableBlood(true);  // 开启塔的血条显示
        mDragTower->setPos(mTowerSitRect.at(index).center());  // 设置塔位置
        mTowers[index] = mDragTower;
        mDragTower = nullptr;

        // 当塔死亡的时候销毁塔
        connect(mTowers[index], &Tower::death, [this, index](Tower *tower) {
            tower->deleteLater();
            mTowers[index] = nullptr;
            m_TowerPlace->play();
        });

        update();
    }
}

void PlayScene::contextMenuEvent(QContextMenuEvent *event)
{
    if (mDragTower) {   // 取消购买卡片
        mCardGold = 0;
        mDragTower->deleteLater();
        mDragTower = nullptr;
        update();
        return;
    }

    // 弹出菜单
    int index = selectTestSitrect(event->pos());
    if (index == -1 || !mTowers[index])
        return;

    bool advanceTower = mTowers[index]->isAdvanced();

    mMenu->clear();
    mMenu->addAction(mDeleteAction);

    // 如果不是高级塔的话可以进行升级
    if (!advanceTower) {
        mMenu->addAction(mUpgradeAction);
        Card *card = findCard(mTowers[index]->type() + 5);  // 对应的高级塔的卡片
        mUpgradeAction->setEnabled(canBuyCard(card));     // 当前金币是否能够升级，不能升级的话，升级功能被禁用
    }

    mMenu->move(QCursor::pos());
    mMenu->show();
}

void PlayScene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    painter.drawPixmap(rect(), mBuffer);
}

void PlayScene::closeEvent(QCloseEvent *)
{

    stopTimer();
    clearAll();
}

void PlayScene::draw(QPainter *painter, GameObject *object)
{
    if (!object) return;

    painter->save();
    painter->translate(object->scenePos());
    painter->rotate(object->rotation());
    object->draw(painter);
    painter->restore();
}

//绘制玩家信息
void PlayScene::drawPlayerInfo(QPainter *painter)
{
    QRectF textRect = QRectF(width() - mRightBg->width() + 50, 700, mRightBg->width() - 50, 300);

    QString text = QString("LIFE：%1\nGOLD：%2").arg(mPlayerHealth).arg(mPlayerGold);
    QFont font("Microsoft YaHei", 24);
    font.setBold(true);
    painter->setFont(font);
    painter->drawText(textRect, Qt::AlignTop | Qt::AlignLeft, text);
}

void PlayScene::drawToBuffer()
{
    mBuffer.fill(Qt::transparent);
    QPainter painter(&mBuffer);

    draw(&painter, mLeftBg);

    painter.save();
    painter.setClipRect(mClipRect); // 将绘制范围限制在底座范围之内

    // 绘制子弹
    for (Bullet *bullet : GameManager::TotalBullet)
        draw(&painter, bullet);

    // 绘制怪物
    for (Monster *monster : mMonsters)
        draw(&painter, monster);

    // 绘制塔
    for (Tower *tower : mTowers)
        draw(&painter, tower);

    painter.restore();

    // 绘制右边的背景
    draw(&painter, mRightBg);

    // 绘制玩家信息
    drawPlayerInfo(&painter);
    // 绘制鼠标拖动时的塔
    draw(&painter, mDragTower);

    // 绘制过场动画
    if (mGameState == LoadingState) {
        QString loadingText = QString("准备\n%1").arg(mLoading);
        QFont font("Microsoft YaHei", 24);
        font.setBold(true);
        painter.setFont(font);
        painter.drawText(mLeftBg->rect(), Qt::AlignCenter,  loadingText);
    }

    update();
}

void PlayScene::collidingObjects()
{
    // 子弹飞出场景之外，删除子弹
    for (int i = GameManager::TotalBullet.size() - 1; i >= 0; --i) {
        Bullet *bullet = GameManager::TotalBullet.at(i);
        if (!bullet->selectTestRect(mClipRect)) {
            GameManager::TotalBullet.removeAt(i);
            bullet->deleteLater();
        }
    }

    // 怪物与子弹的碰撞以及怪物与塔的碰撞
    for (int i = mMonsters.size() - 1; i >= 0; --i) {
        Monster *monster = mMonsters.at(i);

        // 怪物超出了可视范围，玩家承受伤害
        if (monster->scenePos().y() > mClipRect.bottom()) {
            mRoadMonsters[monster->road]--;    // 怪物数量减少
            mPlayerHealth -= monster->atk();
            m_health->play();
            if (mPlayerHealth < 0) mPlayerHealth = 0;
            monster->deleteLater();
            mMonsters.removeAt(i);
            continue;
        }

        if (monster->scenePos().y() < mClipRect.top()&&monster->ifslow()) {
            mRoadMonsters[monster->road]--;    // 怪物数量减少
            mPlayerGold -= monster->gold();
            m_health->play();
            if (mPlayerHealth < 0) mPlayerHealth = 0;
            monster->deleteLater();
            mMonsters.removeAt(i);
            continue;
        }
        QRectF rect = QRectF(monster->scenePos(), monster->rect().size()) & mClipRect;

        // 与塔的碰撞
        for (int j = mTowers.size() - 1; j >= 0; --j) {
            if (!mTowers[j]) continue;

            // 塔承受伤害
            if (rect.intersects(mTowerSitRect.at(j))) {
                mTowers[j]->takeDamage(monster->atk());

                // 普通怪的话直接删除掉怪物，boss可以继续往下走
                if (!monster->boss()) {
                    mRoadMonsters[monster->road]--;    // 怪物数量减少
                    monster->deleteLater();
                    m_NormalDeath->play();
                    monster = nullptr;
                    mMonsters.removeAt(i);
                }
                break;
            }
        }

        if (!monster)
            continue;

        // 与子弹的碰撞
        for (int j = GameManager::TotalBullet.size() - 1; j >= 0; --j) {
            Bullet *bullet = GameManager::TotalBullet.at(j);
            if (bullet->selectTestRect(rect)) {
                monster->takeDamage(bullet->damageValue);
                monster->slowSpeed(bullet->slowspeed);
                monster->addGold(bullet->addmoney);
                m_Bullet->play();
                GameManager::TotalBullet.removeAt(j);
                bullet->deleteLater();
            }
        }
    }
}

void PlayScene::stopTimer()
{
    mFPSTimer->stop();
    mMonsterTimer->stop();
}

//返回点击的是哪个炮塔底座
int PlayScene::selectTestSitrect(const QPointF &pos)
{
    for (int i = mTowerSitRect.size() - 1; i >= 0; --i) {
        QRectF rect = mTowerSitRect.at(i);
        if (rect.contains(pos))
            return i;
    }
    return -1;
}

//根据type查找对应的卡片
Card *PlayScene::findCard(int type)
{
    for (Card *card : mCards) {
        if (card->tower()->type() == type)
            return card;
    }
    return nullptr;
}

//是否可以购买卡片
bool PlayScene::canBuyCard(Card *card)
{
    return (mPlayerGold >= card->gold());
}

//检查当前场景是否结束，结束条件是 boss 死亡，并且怪物列表为空

bool PlayScene::checkSceneSuccess()
{
    return (mBossDied && mMonsters.isEmpty());
}

//检测游戏是否结束
bool PlayScene::checkGameOver()
{
    return (mPlayerHealth <= 0);
}


