﻿#ifndef MONSTER_H
#define MONSTER_H

#include "gameobject.h"
#include "blood.h"

class Blood;

class Monster : public GameObject
{
    Q_OBJECT
public:
    explicit Monster(QObject *parent = nullptr);

    int gold() const { return mGold; }
    bool boss() const { return mBoss; }
    int atk() const { return mAtk; }
    double speed() const { return mSpeed; }
    void setBoss(bool boss);
    void setSpeed(double speed);
    void setType(int type);
    void takeDamage(int damage);
    void slowSpeed(double slowSpeed);
    void addGold(int gold);
    bool ifslow();
    virtual void update();

    int road = 0;
    // 怪物所在的路径
signals:
    void death(Monster *monster);

protected:
    bool mBoss;
    // 是否是boss
    int mGold;
    // 杀死怪物所得的金币值
    int mAtk;
    // 怪物攻击力
    double mSpeed;
    // 怪物移动速度
    bool add;
    bool slow;
    QPixmap mCachePixmap;
    Blood *mBlood;

};

#endif // MONSTER_H
