﻿#ifndef MONSTER_H
#define MONSTER_H
#include "gameobject.h"
#include "blood.h"

class Blood;

class Monster : public GameObject
{
    Q_OBJECT
public:
    explicit Monster(QObject *parent = nullptr);

    int gold() const { return mGold; }
    bool boss() const { return mBoss; }
    int atk() const { return mAtk; }
    double speed() const { return mSpeed; }
    void setBoss(bool boss);
    void setSpeed(double speed);
    void setType(int type);
    void takeDamage(int damage);

    virtual void update();

signals:
    void death(Monster *monster);

protected:
    bool mBoss;
    // 是否是boss
    int mGold;
    // 杀死怪物所得的金币值
    int mAtk;
    // 怪物攻击力
    double mSpeed;
    // 怪物移动速度
    QPixmap mCachePixmap;
    Blood *mBlood;
};

#endif // MONSTER_H
