﻿#include "monster.h"
#include "gameborder.h"
#include <QDebug>
#include <QPainter>
#include <QRandomGenerator>

Monster::Monster(QObject *parent)
    : GameObject(parent)
    , mBoss(false)
    , mGold(0)
    , mAtk(1)
    , mSpeed(50)
    , mBlood(new Blood(this))
{

}
//boss设置
void Monster::setBoss(bool boss)
{
    mBoss = boss;
    QPixmap pixmap = mBoss ? mCachePixmap : mCachePixmap.scaled(mCachePixmap.width() * 0.7, mCachePixmap.height() * 0.7, Qt::KeepAspectRatio);
    setBackground(pixmap);
    //增加血条
    mBlood->setRect(QRectF(0, 0, pixmap.width(), 5));
    mGold = mBoss ? 20 : mGold;                 // boss默认给定20个金币
    mSpeed = mBoss ? mSpeed * 0.7 : mSpeed;     // boss速度0.7慢点
    mAtk = mBoss ? 10 : mAtk;                   // boss默认给定的攻击力为10
    mBlood->maxHealth = mBoss ? 200 : 80;
    mBlood->currentHealth = mBlood->maxHealth;
}

void Monster::setSpeed(double speed)
{
    mSpeed = speed;
}

void Monster::setType(int type)
{
    if (type > 0 && type < 26) {
        QPixmap pixmap(QString(":/resources/monster/%1.png").arg(type));
        mCachePixmap = pixmap.copy(10, 15, pixmap.width() - 20, pixmap.height() - 30);   // 裁剪掉多余的空白部分
        setBoss(type > 20);   // 以20-25作为boss
        // 其它怪物给定随机的金币，但是不知道咋弄，暂时固定吧
//        if (type > 10) mGold = 8;
//        else mGold = 6;
        //找到方法！！！哈哈哈nice
        if (type > 10) mGold = QRandomGenerator::global()->bounded(6, 10);
        else mGold = QRandomGenerator::global()->bounded(4, 8);
    }
}

//伤害

void Monster::takeDamage(int damage)
{
    mBlood->currentHealth -= damage;

    if (mBlood->currentHealth <= 0) {
        mBlood->currentHealth = 0;
        emit death(this);
    }
}

//更新怪物的位置

void Monster::update()
{
    setPos(pos().x(), pos().y() + mSpeed * Time::deltaTime);
}
