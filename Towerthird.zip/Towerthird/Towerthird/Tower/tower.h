﻿#ifndef TOWER_H
#define TOWER_H

#include "gameobject.h"

class Bullet;
class Blood;

class Tower : public GameObject
{
    Q_OBJECT
public:
    explicit Tower(QObject *parent = nullptr);
    virtual Tower *duplicate() const;
    ~Tower();
    virtual void update();
    int type() const { return mType; }
    void setType(int type);
    void copyOther(const Tower &other);
    void enableBlood(bool enable);
    void takeDamage(int damage);
    bool isAdvanced() const { return mIsAdvance; }

signals:
    void death(Tower *tower);

protected:
    bool mIsAdvance;
    // 是否是高级炮塔
    int mType;
    // 炮塔类型
    double mCoolTime;
    // 炮塔发射子弹冷却时间
    double mCoolTimer;
    // 炮塔发射子弹计时器
    Bullet *mBullet;
    // 子弹
    Blood *mBlood;
    // 血条
};

class Card : public GameObject
{
    Q_OBJECT
public:
    explicit Card(QObject *parent = nullptr);

    int gold() const { return mGold; }
    void setGold(int gold);
    Tower *tower() const { return mTower; }

    virtual void draw(QPainter *painter);
protected:
    Tower *mTower;
    int mGold;
};

#endif // TOWER_H
