﻿#ifndef MAINSCENE_H
#define MAINSCENE_H
#include <QMainWindow>

class MyPushButton;
class ChooseLevelScene;

class MainScene : public QMainWindow
{
    Q_OBJECT
public:
    MainScene(QWidget *parent = nullptr);
    ~MainScene();

protected:
    virtual void paintEvent(QPaintEvent *);
    virtual void resizeEvent(QResizeEvent *event);

protected:
    QPixmap mBackground;
    MyPushButton *mStartButton;
    ChooseLevelScene *mChooseLevelScene;
};
#endif // MAINSCENE_H
