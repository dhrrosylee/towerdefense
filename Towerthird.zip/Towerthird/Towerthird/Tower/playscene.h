﻿#ifndef PLAYSCENE_H
#define PLAYSCENE_H


#include <QWidget>

class GameObject;
class QPainter;
class Card;
class Tower;
class Monster;
class QMenu;

class PlayScene : public QWidget
{
    Q_OBJECT
public:
    explicit PlayScene(QWidget *parent = nullptr);
    ~PlayScene();
public slots:
    void loadScene(int index);
    void updateObjects();
    void generateMonster();
    void clearAll();
    void startGame();

protected:
    virtual void mousePressEvent(QMouseEvent *event);
    virtual void mouseMoveEvent(QMouseEvent *event);
    virtual void mouseReleaseEvent(QMouseEvent *event);
    virtual void paintEvent(QPaintEvent *);
    virtual void draw(QPainter *painter, GameObject *object);
    Card *findCard(int type);
    bool canBuyCard(Card *card);

    virtual void contextMenuEvent(QContextMenuEvent *event);
    void drawPlayerInfo(QPainter *painter);
    void drawToBuffer();
    void collidingObjects();
    void stopTimer();
    int selectTestSitrect(const QPointF &pos);


protected:
    GameObject *mLeftBg;
    // 左边的背景
    GameObject *mRightBg;
    // 右边的背景
    GameObject *mTowerSit;
    // 炮塔底座
    Tower *mDragTower;
    // 当前在拖拽的炮塔
    QList<Card *> mCards;
    // 炮塔卡片
    QVector<QRectF> mTowerSitRect;
    // 保存炮塔底座位置
    QVector<Tower *> mTowers;
    // 炮塔
    QVector<Monster *> mMonsters;
    // 怪物
    QTimer *mFPSTimer;
    // FPS计时器
    QTimer *mMonsterTimer;
    // 怪物生成计时器
    int mPlayerHealth;
    // 玩家生命值
    int mPlayerGold;
    // 玩家金币值
    int mCardGold;
    // 卡片的金币值
    int mBossTime;
    // 开始生成boss的时间
    QPixmap mBuffer;
    // 缓冲绘图
    QRectF mClipRect;
    // 绘制范围
    int mCurrentSceneIndex;
    // 当前场景
    bool mBossDied;
    // 判断boss是否死亡，游戏结束条件之一
};

#endif // PLAYSCENE_H
