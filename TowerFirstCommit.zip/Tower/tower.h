﻿#ifndef TOWER_H
#define TOWER_H

#include "gameobject.h"

class Tower : public GameObject
{
    Q_OBJECT
public:
    explicit Tower(QObject *parent = nullptr);

    //此处使用虚函数
    virtual Tower *duplicate() const;
};



#endif // TOWER_H
