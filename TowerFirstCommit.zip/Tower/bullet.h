﻿#ifndef BULLET_H
#define BULLET_H

#include "gameobject.h"

class Bullet : public GameObject
{
public:
    explicit Bullet(QObject *parent = nullptr);
};

#endif // BULLET_H
