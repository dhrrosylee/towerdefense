﻿#ifndef CARD_H
#define CARD_H
#include "gameobject.h"
#include "tower.h"
class Card : public GameObject
{
    Q_OBJECT
public:
    explicit Card(QObject *parent = nullptr);
    void setTowerIndex(int index);//给塔编号
    Tower *tower() const { return mTower; }
protected:
    Tower *mTower;
};

#endif // CARD_H
