﻿#include "tower.h"

Tower::Tower(QObject *parent)
    : GameObject(parent)
{
    //初始化
    setBackground(QPixmap(":/resources/tower/tower1primary.png"));
}

Tower *Tower::duplicate() const
{
    //复制塔
    Tower *tower = new Tower;
    tower->copyOther(*this);
    return tower;
}

