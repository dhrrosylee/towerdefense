﻿#include "card.h"

Card::Card(QObject *parent)
    : GameObject(parent)
    , mTower(new Tower(this))
{
    //底座，p图搞得，怕麻烦，所以是固定的个数，不适用于加减卡片个数，有时间再说吧
    setBackground(QPixmap(":/resources/materials/cardsitdeep.png"));
    mTower->setBackground(QPixmap(":/resources/tower/tower1primary.png"));
    mTower->setPos(QPointF((width() - mTower->width()) * 0.5, (height() - mTower->height()) * 0.5));
}
//给塔编号
void Card::setTowerIndex(int index)
{
    //根据相应编号，把塔的各种信息初始化，主要是地址
    QString path;
    if (index > 0 && index <= 5)
        path = QString(":/resources/tower/tower%1primary.png").arg(index);
    else if (index > 5 && index <= 10)
        path = QString(":/resources/tower/tower%1advanced.png").arg(index - 5);

    if (!path.isEmpty())
        mTower->setBackground(QPixmap(path));
}

