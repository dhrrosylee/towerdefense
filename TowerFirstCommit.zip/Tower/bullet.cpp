﻿#include "bullet.h"

Bullet::Bullet(QObject *parent)
    : GameObject(parent)
{

}
