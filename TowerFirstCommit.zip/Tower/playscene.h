﻿#ifndef PLAYSCENE_H
#define PLAYSCENE_H

#include <QWidget>

class GameObject;
class QPainter;
class Card;
class Tower;

class PlayScene : public QWidget
{
    Q_OBJECT
public:
    explicit PlayScene(QWidget *parent = nullptr);

public slots:
    //监听选择关卡场景
    void setSceneIndex(int index);

protected:
    virtual void mousePressEvent(QMouseEvent *event);
    virtual void mouseMoveEvent(QMouseEvent *event);
    virtual void mouseReleaseEvent(QMouseEvent *event);
    virtual void paintEvent(QPaintEvent *);
    virtual void draw(QPainter *painter, GameObject *object);

protected:
    GameObject *mLeftBg;
    // 左边的背景
    GameObject *mRightBg;
    // 右边的背景
    GameObject *mTowerSit;
    // 炮塔底座
    Tower *mDragTower;
    // 当前在拖拽的炮塔
    QList<Card *> mCards;
    // 炮塔卡片
    QVector<QRectF> mTowerSitRect;
    // 保存炮塔底座位置
    QVector<Tower *> mTowers;
    // 炮塔
};

#endif // PLAYSCENE_H
