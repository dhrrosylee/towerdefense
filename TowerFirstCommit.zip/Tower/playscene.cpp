﻿#include "playscene.h"
#include "tower.h"
#include "card.h"
#include <QPainter>
#include <QDebug>
#include <QMouseEvent>

PlayScene::PlayScene(QWidget *parent)
    : QWidget(parent)
    , mLeftBg(new GameObject(this))
    , mRightBg(new GameObject(this))
    , mTowerSit(new GameObject(mLeftBg))
    , mDragTower(nullptr)
{
    hide();
    setFixedSize(1000, 1000);

    // 背景图片
    QPixmap left = QPixmap(":/resources/map/map3.jpg");
    QPixmap right = QPixmap(":/resources/materials/rightpicture.png");

    left = left.copy(0, 0, left.width(), left.height() - 200);
    // -200是为了去掉底部的水印
    right = right.scaled(1000 - left.width(), left.height());
    mLeftBg->setBackground(left);
    mRightBg->setBackground(right);
    mRightBg->setPos(QPointF(left.width(), 0));

    // 炮塔底座
    QPixmap towerSit = QPixmap(":/resources/materials/towersit.png");
    mTowerSit->setBackground(towerSit);
    mTowerSit->setRect(QRectF(0, 0, towerSit.width(), towerSit.height()));
    mTowerSit->setPos(QPointF((left.width() - towerSit.width()) * 0.5, (left.height() - towerSit.height()) * 0.5));

    // 计算炮塔底座位置
    const int TowerRows = 9;
    const int TowerColumns = 5;

    double x = mTowerSit->scenePos().x();
    double y = mTowerSit->scenePos().y();
    double w = towerSit.width() / TowerColumns;
    double h = towerSit.height() / TowerRows;
    mTowerSitRect.resize(TowerRows * TowerColumns);
    mTowers.resize(TowerRows * TowerColumns);

    for (int i = 0; i < TowerRows; ++i) {
        for (int j = 0; j < TowerColumns; ++j)
            mTowerSitRect[i * TowerColumns + j] = QRectF(x + j * w, y + i * h, w, h);
    }

    // 炮塔卡片
    x = 40;
    y = 28;
    for (int i = 0; i < 5; ++i) {
        Card *card = new Card(mRightBg);
        Card *advancedCard = new Card(mRightBg);

        card->setTowerIndex(i + 1);
        advancedCard->setTowerIndex(i + 6);
        mCards.append(card);
        mCards.append(advancedCard);

        if (i != 0) y += card->height() + 1;

        card->setPos(QPointF(x, y));
        advancedCard->setPos(QPointF(x + card->width() + 10, y));
    }

    setMouseTracking(true);
}

//设置当前关卡
void PlayScene::setSceneIndex(int index)
{
    QPixmap leftBg = index ? QPixmap(":/resources/map/map1.jpg") : QPixmap(":/resources/map/map3.jpg");
    mLeftBg->setBackground(leftBg.copy(0, 0, leftBg.width(), leftBg.height() - 200));
}

void PlayScene::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        foreach (Card *card, mCards) {
            if (card->selectTest(event->pos())) {
                mDragTower = card->tower()->duplicate();
                break;
            }
        }
    } else if (event->button() == Qt::RightButton) {
        if (mDragTower) {
            mDragTower->deleteLater();
            mDragTower = nullptr;
            update();
        }
    }
}

void PlayScene::mouseMoveEvent(QMouseEvent *event)
{
    if (mDragTower) {
        mDragTower->setPos(QPointF(event->x() - mDragTower->width() * 0.5, event->y() - mDragTower->height() * 0.5));
        update();
        return;
    }

    bool cursorChanged = false;
    foreach (Card *card, mCards) {
        if (card->selectTest(event->pos())) {
            cursorChanged = true;
            setCursor(Qt::PointingHandCursor);
            break;
        }
    }

    if (!cursorChanged)
        unsetCursor();
}

void PlayScene::mouseReleaseEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton && mDragTower) {
        for (int i = mTowerSitRect.size() - 1; i >= 0; --i) {
            QRectF rect = mTowerSitRect.at(i);
            if (rect.contains(event->pos())) {
                if (mTowers[i]) break;     // 当前位置已经存在炮塔了

                mDragTower->setPos(QPointF(rect.x() + (rect.width() - mDragTower->width()) * 0.5, rect.y() + (rect.height() - mDragTower->height()) * 0.5));
                mTowers[i] = mDragTower;
                mDragTower = nullptr;
                update();
                break;
            }
        }
    }
}

void PlayScene::paintEvent(QPaintEvent *)
{
    QPainter painter(this);

    draw(&painter, mLeftBg);//左边的背景
    draw(&painter, mRightBg);//右边

    foreach (Tower *tower, mTowers)
        draw(&painter, tower);//绘制塔

    draw(&painter, mDragTower);//
}

void PlayScene::draw(QPainter *painter, GameObject *object)
{
    if (!object) return;
//储存
    painter->save();
    painter->translate(object->pos());
    painter->rotate(object->rotation());
    object->draw(painter);
    painter->restore();
}


